import os
class KoreaMacroProvider:
    """
    한국 공식 매크로 데이터 연결 자리.
    ECOS_API_KEY / KOSIS_API_KEY를 환경변수 또는 Streamlit Secrets에 저장한다.
    실제 모델에서는 observation_date와 release_date를 모두 보존한다.
    """
    def __init__(self):
        self.ecos_key = os.getenv("ECOS_API_KEY")
        self.kosis_key = os.getenv("KOSIS_API_KEY")

    def available(self):
        return bool(self.ecos_key or self.kosis_key)
